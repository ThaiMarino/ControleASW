package entidadeClassificacaoDinamica;

public class Autor {
	private String filiacao;
	
	public Autor(String filiacao) {
		this.filiacao = filiacao;
	}

	public Autor() {
	}

	public String getFiliacao() {
		return filiacao;
	}

	public void setFiliacao(String filiacao) {
		this.filiacao = filiacao;
	}

	
	

}
