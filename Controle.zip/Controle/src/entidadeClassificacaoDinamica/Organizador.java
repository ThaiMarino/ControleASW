package entidadeClassificacaoDinamica;

public class Organizador {
	private String titulacao;

	public Organizador() {
		
	}

	public String getTitulacao() {
		return titulacao;
	}

	public void setTitulacao(String titulacao) {
		this.titulacao = titulacao;
	}
	
	
}
