package Fronteira;

import Controle.ControleOrganizador;
import Entidade.Organizador;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Organizador o1 = new Organizador("Isa", "ian@gmail.com", "117777777");
		ControleOrganizador control = new ControleOrganizador();
		control.salvar(o1);
	}

}
