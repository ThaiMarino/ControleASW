package Entidade;

public class Organizador extends Pessoa {
	
	private String fone;
	
	public Organizador() {
		super();
	}
	
	public Organizador(String nome, String email, String fone) {
		super.setNome (nome);
		super.setEmail (email);
		this.fone = fone;
	}
	
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	
	

}
