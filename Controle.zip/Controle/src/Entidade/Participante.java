package Entidade;

public interface Participante {
	public String getNome();
	public String getCpf();
	public String getEmail();

}
