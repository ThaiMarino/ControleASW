package Entidade;

import java.time.LocalDate;

public class AutorArtigo {
	// associacao de muitos para muitos com classe associativa
	private Autor autor;
	private Artigo artigo;
	private  LocalDate dataSubmissao;
	public Autor getAutor() {
		return autor;
	}
	public void setAutor(Autor autor) {
		this.autor = autor;
	}
	public Artigo getArtigo() {
		return artigo;
	}
	public void setArtigo(Artigo artigo) {
		this.artigo = artigo;
	}
	public LocalDate getDataSubmissao() {
		return dataSubmissao;
	}
	public void setDataSubmissao(LocalDate dataSubmissao) {
		this.dataSubmissao = dataSubmissao;
	}
	
	

}
