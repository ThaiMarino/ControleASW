package Entidade;

import java.time.LocalDate;

public class Evento {
	LocalDate dia;
	String nome;
	String tema;
	
	Participante participante;
	
//	Autor autor;
//	Ouvinte ouvinte;
//	Organizador organidor;

}
