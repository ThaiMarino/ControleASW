package Controle;

import ControleDao.DaoOrganizador;
import Entidade.Organizador;

public class ControleOrganizador {
	//dependencia estrutural
	//não deve ser utilizado
	//Organizador org = new Organizador();
	//utilize a dependencia não estrutura por parametro
	//veja o metodo salvar
	
	public void salvar (Organizador org) {
		// opção de criar um objeto
//		DaoOrganizador daoOrg = new DaoOrganizador();
//		daoOrg.salvar(org);
		//opção de usar o metodo static sem instanciar um objeto
		DaoOrganizador.salvar(org);
	}
	
	public void excluir (int id) {
		System.out.println("Apagando " + id);
	}
	
	public Organizador pesquisar (String nome) {
		return null;
	}

}
