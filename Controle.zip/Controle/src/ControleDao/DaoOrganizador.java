package ControleDao;



import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;

import Entidade.Organizador;

public class DaoOrganizador {
	
	public static boolean salvar(Organizador org)  {
		
		String driverName = "com.mysql.jdbc.Driver";
	    try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    String serverName = "localhost";    //caminho do servidor do BD
	    String mydatabase = "mysql";        //nome do seu banco de dados
	    String url = "jdbc:mysql://" + serverName + "/" + mydatabase;
	    String username = "root";        //nome de um usuário de seu BD      
	    String password = "12345";      //sua senha de acesso

	    Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//comando salvar
		// insert table
	    
	    System.out.println("Nome: " + org.getNome() + " Fone: " + org.getFone());
		String insertSQL = "INSERT INTO Organizador (nome, fone, email) VALUES ('"
                + org.getNome() + "','"
                + org.getFone() + "','"
                + org.getEmail() + "')";
        try {
            Statement st = conn.createStatement();
            st.executeUpdate(insertSQL);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DaoOrganizador.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
	}

}
